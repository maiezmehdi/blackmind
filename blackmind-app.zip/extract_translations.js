const fs = require('fs');

// We have an export const translations = { fr: {...}, en: {...} }; in translations.ts
// It might be easier to just evaluate it. Since it's TS, maybe not.
// Wait, we can compile it or use ts-node.
