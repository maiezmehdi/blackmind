import re

with open('pages/SettingsPage.tsx', 'r') as f:
    content = f.read()

# Introduce a scoped function
# Replace `case 'accessibility':\n        return (`
# With:
# `case 'accessibility': {\n        const tAcc = (key: string) => t(`settings.accessibility.${key}`);\n        return (`

replacement = """      case 'accessibility': {
        const tAcc = (key: string) => t(`settings.accessibility.${key}`);
        return ("""

content = re.sub(r"case 'accessibility':\s*return \(", replacement, content)

# Replace t('settings.accessibility.XXXX') with tAcc('XXXX')
content = re.sub(r"t\('settings\.accessibility\.([^']+)'\)", r"tAcc('\1')", content)

# Since we opened a block `{` for the case, we need to close it.
# Let's find where the accessibility case ends. The next case is probably `case 'appearance':` or `case 'integrations':` or `case 'notifications':` or `case 'security':` or `case 'data':`

content = re.sub(r"(?=\s*case 'appearance':)", r"      }\n", content)

with open('pages/SettingsPage.tsx', 'w') as f:
    f.write(content)

