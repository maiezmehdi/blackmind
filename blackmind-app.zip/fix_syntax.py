import re

with open('pages/SettingsPage.tsx', 'r') as f:
    content = f.read()

# Let's see what went wrong.
lines = content.split('\n')
for i, line in enumerate(lines):
    if "case 'accessibility': {" in line:
        print(f"Start at {i}")
    if "      }\n      case" in content:
        # the regex matched incorrectly.
        pass

