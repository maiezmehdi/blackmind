import re

with open('pages/PricingPage.tsx', 'r') as f:
    content = f.read()

# I need `language` from `useLanguage` to know the locale
# In PricingPage.tsx:
# const { t, currentUser, upgradeSubscription } = useCourseContext();
# Let's add useLanguage

content = content.replace(
    'const { t, currentUser, upgradeSubscription } = useCourseContext();',
    'const { t, currentUser, upgradeSubscription } = useCourseContext();\n  const { language } = useLanguage();'
)
content = content.replace(
    "import { useCourseContext } from '../store/useCourseStore';",
    "import { useCourseContext } from '../store/useCourseStore';\nimport { useLanguage } from '../contexts/LanguageContext';"
)

# Format the finalPrice
content = content.replace(
    '<span className="text-4xl font-bold text-gemini-accent">{finalPrice}€</span>',
    '<span className="text-4xl font-bold text-gemini-accent">{new Intl.NumberFormat(language === "fr" ? "fr-FR" : "en-US", { style: "currency", currency: "EUR", minimumFractionDigits: 0 }).format(Number(finalPrice))}</span>'
)

with open('pages/PricingPage.tsx', 'w') as f:
    f.write(content)

print("patched prices in pricing")
