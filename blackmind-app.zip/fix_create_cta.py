import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

# Add a summary and CTA to storytelling and course generation
content = content.replace(
    'setMessages(prev => [...prev, { role: \'assistant\', content: "Storytelling structure generated.", timestamp: new Date() }]);',
    'setMessages(prev => [...prev, { role: \'assistant\', content: `Structure générée avec succès ! (${responseData.modules.length} scènes).`, suggestions: ["__ACTION_PREVIEW__"], timestamp: new Date() }]);'
)

content = content.replace(
    'setMessages(prev => [...prev, { role: \'assistant\', content: commentary, suggestions, timestamp: new Date() }]);',
    'setMessages(prev => [...prev, { role: \'assistant\', content: commentary, suggestions: [...(suggestions || []), "__ACTION_PREVIEW__"], timestamp: new Date() }]);'
)

# Render the button
render_sug = """
                        {m.suggestions.map((suggestion: string, sIdx: number) => {
                          if (suggestion === '__ACTION_PREVIEW__') {
                            return (
                              <button
                                key={sIdx}
                                onClick={() => setView('preview')}
                                className="px-6 py-2.5 bg-gemini-accent text-gemini-bg rounded-full text-[10px] font-bold tracking-wider hover:scale-105 transition-all shadow-lg whitespace-nowrap"
                              >
                                {t('create.viewResult', { defaultValue: 'Voir le résultat ->' })}
                              </button>
                            );
                          }
                          return (
                          <button 
                            key={sIdx}
                            onClick={() => handleGenerateCourse(suggestion)}
                            className="px-4 py-2.5 bg-gemini-surface border border-gemini-border rounded-full text-[10px] font-bold tracking-wider text-gemini-dim hover:text-gemini-accent hover:border-gemini-accent hover:shadow-md hover:-translate-y-0.5 transition-all shadow-sm whitespace-nowrap group/sug"
                          >
                            <Plus size={12} className="inline mr-1 group-hover/sug:rotate-90 transition-transform" /> {suggestion}
                          </button>
                        )})}
"""

content = re.sub(
    r'\{m\.suggestions\.map\(\(suggestion: string, sIdx: number\) => \([^)]+\)\s*\}\s*</button>\s*\)\)\}',
    render_sug.strip(),
    content,
    flags=re.MULTILINE | re.DOTALL
)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)

print("patched CTA")
