import json

with open('locales/en.json', 'r') as f:
    en = json.load(f)

# Ensure settings has everything
en_settings = en.setdefault('settings', {})

additions = {
    "visualIdentity": "Visual Identity",
    "changeImage": "Change Image",
    "remove": "Remove",
    "accountInfo": "Account Info",
    "username": "Username",
    "email": "Email",
    "verified": "Verified",
    "language": "Language",
    "theme": "System Theme",
    "typography": "Typography & Assistant",
    "font": "Font",
    "aiAssistant": "Floating AI Assistant",
    "storage": "Storage & Export",
    "exportData": "Export My Data",
    "exportDataDesc": "Download a JSON archive.",
    "clearCache": "Clear Cache",
    "clearCacheDesc": "Deletes temporary local data.",
    "clean": "Clean",
    "deleteAccount": "Delete Account",
    "deleteAccountDesc": "This action is irreversible.",
    "logout": "Logout",
    "needHelp": "Need help?",
    "helpText": "Check our knowledge base or contact support.",
    "docs": "Documentation",
    "notifications": {
      "email": "Email Notifications",
      "emailDesc": "Receive course summaries.",
      "push": "Push Notifications",
      "pushDesc": "Mobile study reminders.",
      "ai": "AI Updates",
      "aiDesc": "Info on new models."
    },
    "appearance": {
      "fontDesc": "Outfit (Interface) / Inter (Body)",
      "assistantDesc": "Show the assistant on all pages."
    }
}

for k, v in additions.items():
    if k not in en_settings:
        en_settings[k] = v
    elif isinstance(v, dict):
        if not isinstance(en_settings[k], dict):
            en_settings[k] = {}
        for sub_k, sub_v in v.items():
            en_settings[k][sub_k] = sub_v

with open('locales/en.json', 'w') as f:
    json.dump(en, f, indent=2)

print("en.json settings populated")
