with open('pages/MarketplacePage.tsx', 'r') as f:
    content = f.read()

def_price = """  const { language } = useLanguage();
  const formatPrice = (priceStr: string | undefined) => {
    if (!priceStr) return priceStr;
    if (priceStr === 'Gratuit' || priceStr === 'Free') return t('marketplace.free');
    const num = parseFloat(priceStr);
    if (isNaN(num)) return priceStr;
    return new Intl.NumberFormat(language === 'fr' ? 'fr-FR' : 'en-US', { style: 'currency', currency: 'EUR' }).format(num);
  };
"""

content = content.replace(
    'const { marketplaceCourses, buyCourse, courses, t } = useCourseContext();',
    'const { marketplaceCourses, buyCourse, courses, t } = useCourseContext();\n' + def_price
)

with open('pages/MarketplacePage.tsx', 'w') as f:
    f.write(content)
