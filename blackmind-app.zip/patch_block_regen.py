import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

regen_btn = """<button onClick={() => openAiModal({ action: 'refine-regenerate', modId: mod.id, lesId: lesson.id, blockId: block.id, title: 'Améliorer avec l\\'IA', placeholder: 'Quelles modifications apporter ?' })} className="p-1.5 hover:bg-gemini-bg rounded text-gemini-dim hover:text-gemini-accent" title="Améliorer avec l'IA"><Sparkles size={14}/></button>\n                                            """

content = content.replace(
    '<button onClick={() => moveBlock(mod.id, lesson.id, block.id, \'up\')}',
    regen_btn + '<button onClick={() => moveBlock(mod.id, lesson.id, block.id, \'up\')}'
)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
