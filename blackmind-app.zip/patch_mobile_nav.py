import re

with open('App.tsx', 'r') as f:
    content = f.read()

# Remove the bottom nav
content = re.sub(r'\{isMobile && \(\s*<nav className="fixed bottom-0.*?</nav>\s*\)\}', '', content, flags=re.DOTALL)

# Remove pb-20 on mobile
content = content.replace(
    '<div className={`flex-1 ${isFullHeightPage ? \'overflow-hidden flex flex-col\' : \'overflow-y-auto no-scrollbar\'} ${isMobile && !isFullHeightPage ? \'pb-20\' : \'\'}`}>',
    '<div className={`flex-1 ${isFullHeightPage ? \'overflow-hidden flex flex-col\' : \'overflow-y-auto no-scrollbar\'}`}>'
)

with open('App.tsx', 'w') as f:
    f.write(content)
print("Removed mobile bottom nav and pb-20")
