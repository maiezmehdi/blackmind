import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

# Replace condition
old_cond = """{!generatedCourse ? (
             <div className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-50">"""
new_cond = """{(!generatedCourse && !generatedStory) ? (
             <div className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-50">"""
content = content.replace(old_cond, new_cond)

# Add story rendering
old_render = """             </div>
           ) : ("""
new_render = """             </div>
           ) : generatedStory ? (
             <div className="max-w-4xl mx-auto p-8 rounded-3xl border border-purple-500/30 bg-purple-500/5 space-y-8 shadow-2xl animate-in fade-in zoom-in-95 duration-500">
               <div className="space-y-2">
                 <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-400 text-[10px] font-bold uppercase tracking-widest border border-purple-500/30">
                   <BookOpen size={14} /> Storytelling Mode
                 </div>
                 <h1 className="text-4xl md:text-5xl font-bold font-outfit text-gemini-accent tracking-tight">{generatedStory.title}</h1>
                 <p className="text-xl text-gemini-dim">{generatedStory.logline}</p>
               </div>
               <div className="space-y-6">
                 {generatedStory.scenes && generatedStory.scenes.map((scene: any, idx: number) => (
                   <div key={idx} className="p-6 rounded-2xl bg-gemini-surface/80 border border-gemini-border shadow-sm space-y-4">
                     <div className="flex items-center justify-between border-b border-gemini-border pb-4">
                       <h3 className="font-bold text-lg text-gemini-text">{scene.title}</h3>
                       <span className="text-xs font-mono text-purple-400 bg-purple-500/10 px-2 py-1 rounded-lg border border-purple-500/20">{scene.setting}</span>
                     </div>
                     <p className="text-gemini-dim font-medium leading-relaxed">{scene.action}</p>
                     {scene.characters && scene.characters.length > 0 && (
                       <div className="flex flex-wrap gap-2 pt-2">
                         {scene.characters.map((char: string, i: number) => (
                           <span key={i} className="text-[10px] font-bold uppercase tracking-widest bg-gemini-bg text-gemini-dim px-3 py-1 rounded-full border border-gemini-border">
                             {char}
                           </span>
                         ))}
                       </div>
                     )}
                   </div>
                 ))}
               </div>
             </div>
           ) : ("""
content = content.replace(old_render, new_render)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
