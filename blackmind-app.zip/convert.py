import re
import json

with open('translations.ts', 'r') as f:
    text = f.read()

# We can try to evaluate it, or simply use node with .mjs
