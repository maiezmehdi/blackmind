import re

with open('pages/ProgressPage.tsx', 'r') as f:
    content = f.read()

# Make the date format
date_generator = """  const { language } = useLanguage();
  const data = useMemo(() => {
    const formatter = new Intl.DateTimeFormat(language === 'fr' ? 'fr-FR' : 'en-US', { weekday: 'short', day: 'numeric' });
    const today = new Date();
    return [6, 5, 4, 3, 2, 1, 0].map(daysAgo => {
      const d = new Date(today);
      d.setDate(d.getDate() - daysAgo);
      return {
        name: formatter.format(d).replace(/\./g, ''), // e.g. "dim 12"
        hours: Math.floor(Math.random() * 5 * 10) / 10 + 1
      };
    });
  }, [language]);"""

content = re.sub(
    r'const data = useMemo\(\(\) => \[.*?\]\, \[t\]\);',
    date_generator,
    content,
    flags=re.DOTALL
)

# And inject useLanguage in component
content = content.replace(
    'const { courses, t } = useCourseContext();',
    'const { courses, t } = useCourseContext();\n  const { language } = useLanguage();'
)
content = content.replace(
    "import { useCourseContext } from '../store/useCourseStore';",
    "import { useCourseContext } from '../store/useCourseStore';\nimport { useLanguage } from '../contexts/LanguageContext';"
)

# And AreaChart cartesian grid
content = content.replace(
    '<AreaChart data={activityData}>',
    '<AreaChart data={activityData}>\n                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={borderColor} />'
)

with open('pages/ProgressPage.tsx', 'w') as f:
    f.write(content)
print("patched progress chart")
