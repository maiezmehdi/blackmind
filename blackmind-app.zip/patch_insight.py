import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

# Replace getInsightColorClass call and the function itself
# We can just remove the function usage
content = re.sub(
    r'\$\{getInsightColorClass\(block\.id\)\}',
    'bg-gemini-warning-bg border-gemini-warning-border text-gemini-warning-text',
    content
)
content = re.sub(
    r'\$\{getInsightAccentClass\(block\.id\)\}',
    'text-gemini-warning-text',
    content
)

# Also fix prose-sm text-gemini-text/90 italic to just text-gemini-warning-text so it has contrast
content = content.replace(
    'className="prose-gemini prose-sm text-gemini-text/90 italic"',
    'className="prose-gemini prose-sm text-gemini-warning-text font-medium"'
)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)

print("patched insight block")
