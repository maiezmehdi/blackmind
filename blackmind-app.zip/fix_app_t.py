with open('App.tsx', 'r') as f:
    content = f.read()

content = content.replace('const { language, t: tLang } = useLanguage();', 'const { language, t } = useLanguage();')

with open('App.tsx', 'w') as f:
    f.write(content)
