with open('pages/ProgressPage.tsx', 'r') as f:
    content = f.read()

content = content.replace("const { t } = useCourseContext();", "const { t } = useCourseContext();\n  const { language } = useLanguage();")

with open('pages/ProgressPage.tsx', 'w') as f:
    f.write(content)
