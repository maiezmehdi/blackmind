import json

with open('locales/fr.json', 'r') as f:
    fr = json.load(f)

with open('locales/en.json', 'r') as f:
    en = json.load(f)

fr["common"]["searchCourse"] = "Rechercher un cours..."
en["common"]["searchCourse"] = "Search a course..."

fr["common"]["anonymous"] = "Anonyme"
en["common"]["anonymous"] = "Anonymous"

fr["common"]["general"] = "Général"
en["common"]["general"] = "General"

fr["home"]["heroTitle1"] = "Transformez votre expertise en contenu qui"
en["home"]["heroTitle1"] = "Turn your expertise into content that"

fr["home"]["heroTitle2"] = "captive."
en["home"]["heroTitle2"] = "captivates."

fr["home"]["heroSubtitle"] = "Générez des cours, des scripts et des histoires qui engagent votre audience — propulsés par l'intelligence artificielle."
en["home"]["heroSubtitle"] = "Generate courses, scripts, and stories that engage your audience — powered by artificial intelligence."

fr["home"]["by"] = "Par"
en["home"]["by"] = "By"

fr["home"]["modulesCount"] = "module(s)"
en["home"]["modulesCount"] = "module(s)"

fr["home"]["completed"] = "complété"
en["home"]["completed"] = "completed"

fr["home"]["modulesCountPlural"] = "modules"
en["home"]["modulesCountPlural"] = "modules"

fr["home"]["modulesCountSingular"] = "module"
en["home"]["modulesCountSingular"] = "module"

with open('locales/fr.json', 'w') as f:
    json.dump(fr, f, indent=2)

with open('locales/en.json', 'w') as f:
    json.dump(en, f, indent=2)
