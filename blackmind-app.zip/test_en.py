import json

with open('locales/en.json', 'r') as f:
    en = json.load(f)

print(list(en['settings'].keys()))
