import re

with open('pages/MarketplacePage.tsx', 'r') as f:
    content = f.read()

content = content.replace(
    'const [purchaseSuccess, setPurchaseSuccess] = useState(false);',
    'const [purchaseSuccess, setPurchaseSuccess] = useState(false);\n  const [favorites, setFavorites] = useState<string[]>([]);'
)

# For grid cards heart
content = content.replace(
    '<button \n                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}\n                  className="absolute bottom-4 right-4 p-2.5 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-300 hover:bg-white hover:text-black z-10"\n                >\n                  <Heart size={18} />\n                </button>',
    """<button 
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); setFavorites(prev => prev.includes(course.id) ? prev.filter(id => id !== course.id) : [...prev, course.id]); }}
                  className={`absolute bottom-4 right-4 p-2.5 backdrop-blur-md border border-white/20 rounded-xl transition-all duration-300 z-10 active:scale-90 ${favorites.includes(course.id) ? 'bg-red-500 text-white opacity-100 translate-y-0' : 'bg-white/10 text-white opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 hover:bg-white hover:text-black'}`}
                >
                  <Heart size={18} fill={favorites.includes(course.id) ? 'currentColor' : 'none'} />
                </button>"""
)

# For featured card heart
content = content.replace(
    '<button className="p-4 bg-gemini-bg border border-gemini-border rounded-2xl text-gemini-dim hover:text-red-500 hover:border-red-500/30 transition-all">',
    """<button 
                onClick={(e) => { e.stopPropagation(); setFavorites(prev => prev.includes(featuredCourse.id) ? prev.filter(id => id !== featuredCourse.id) : [...prev, featuredCourse.id]); }}
                className={`p-4 border rounded-2xl transition-all active:scale-90 ${favorites.includes(featuredCourse.id) ? 'bg-red-500/10 border-red-500/30 text-red-500' : 'bg-gemini-bg border-gemini-border text-gemini-dim hover:text-red-500 hover:border-red-500/30'}`}>"""
)
content = content.replace(
    '<Heart size={20} />',
    '<Heart size={20} fill={favorites.includes(featuredCourse.id) ? "currentColor" : "none"} />',
    1 # Only replace the first one which is featured course, wait the previous replace didn't change the heart, let's make sure.
)

with open('pages/MarketplacePage.tsx', 'w') as f:
    f.write(content)
