import json

with open('locales/en.json', 'r') as f:
    en = json.load(f)

en['nav'] = {
    "explorer": "Explore",
    "create": "Create",
    "marketplace": "Marketplace",
    "progress": "Progress",
    "workspaces": "Workspaces",
    "settings": "Settings",
    "pricing": "Pricing"
}

en['common']['confirmDeleteCourse'] = "Are you sure you want to delete this course? This action is irreversible."
en['common']['confirmDeleteDesc'] = "This action is irreversible. All associated data will be permanently deleted."
en['common']['confirmDeleteTitle'] = "Delete this item?"
en['common']['confirmDelete'] = "Are you sure you want to delete this item?"
en['common']['delete'] = "Delete"
en['common']['cancel'] = "Cancel"

with open('locales/en.json', 'w') as f:
    json.dump(en, f, indent=2)

with open('locales/fr.json', 'r') as f:
    fr = json.load(f)

fr['nav'] = {
    "explorer": "Explorer",
    "create": "Créer",
    "marketplace": "Marketplace",
    "progress": "Progression",
    "workspaces": "Espaces",
    "settings": "Paramètres",
    "pricing": "Abonnements"
}
with open('locales/fr.json', 'w') as f:
    json.dump(fr, f, indent=2)

print("updated en.json and fr.json nav")
