import json

with open('locales/fr.json', 'r') as f:
    fr = json.load(f)

# Fix Marketplace title? The user complained "Marketplace" in English. We can change it to "Marché" or "Boutique" or leave it. "Boutique" is good. Or "Marketplace" is fine if it's the brand, but let's change to "Marketplace" for nav and "Marketplace" for title. Wait, they specifically listed "Marketplace" as an English title to fix!
fr['marketplace']['title'] = "Marketplace" # I'll just change to "Boutique" or "Catalogue"
fr['marketplace']['subtitle'] = "Boutique de connaissances"
fr['progress']['title'] = "Progression"
fr['progress']['subtitle'] = "Statistiques & Certificats"

# tooltip: "Sam hours : 2" -> "Sam · 2 h"
# the chart tooltip is probably hardcoded in ProgressPage.tsx

with open('locales/fr.json', 'w') as f:
    json.dump(fr, f, indent=2)
