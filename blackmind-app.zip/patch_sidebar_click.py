import re

with open('components/Layout/Sidebar.tsx', 'r') as f:
    content = f.read()

content = content.replace(
    'const SidebarItem = ({ to, icon: Icon, label, active, collapsed }: { to: string, icon: any, label: string, active: boolean, collapsed: boolean }) => (',
    'const SidebarItem = ({ to, icon: Icon, label, active, collapsed, onClick }: { to: string, icon: any, label: string, active: boolean, collapsed: boolean, onClick?: () => void }) => ('
)
content = content.replace(
    '  <Link \n    to={to}',
    '  <Link \n    to={to}\n    onClick={onClick}'
)

content = content.replace(
    'interface SidebarProps {\n  isCollapsed: boolean;\n  onToggle: () => void;\n  pathname: string;\n}',
    'interface SidebarProps {\n  isCollapsed: boolean;\n  onToggle: () => void;\n  pathname: string;\n  onLinkClick?: () => void;\n}'
)
content = content.replace(
    'const Sidebar: React.FC<SidebarProps> = ({ isCollapsed, onToggle, pathname }) => {',
    'const Sidebar: React.FC<SidebarProps> = ({ isCollapsed, onToggle, pathname, onLinkClick }) => {'
)

# And then for every SidebarItem:
content = re.sub(
    r'<SidebarItem (.*?) />',
    r'<SidebarItem \1 onClick={onLinkClick} />',
    content
)

with open('components/Layout/Sidebar.tsx', 'w') as f:
    f.write(content)

with open('App.tsx', 'r') as f:
    app_content = f.read()

app_content = app_content.replace(
    '<Sidebar isCollapsed={false} onToggle={() => setSidebarOpen(false)} pathname={location.pathname} />',
    '<Sidebar isCollapsed={false} onToggle={() => setSidebarOpen(false)} onLinkClick={() => setSidebarOpen(false)} pathname={location.pathname} />'
)

with open('App.tsx', 'w') as f:
    f.write(app_content)

print("Patched Sidebar to close on mobile when clicking a link")
