import json

# Update FR
with open('locales/fr.json', 'r') as f:
    fr = json.load(f)

# The user explicitly asked to restructure to nested JSON:
# settings -> tabs -> accessibility
# settings -> accessibility -> title, subtitle, etc.

if 'accessibility' in fr:
    # If it's at root, move it (it shouldn't be based on our previous test, but just in case)
    if 'accessibility' not in fr.get('settings', {}):
        fr.setdefault('settings', {})['accessibility'] = fr['accessibility']
    del fr['accessibility']

if 'settings' in fr and 'accessibility' in fr['settings']:
    # Ensure it's the requested structure
    acc = fr['settings']['accessibility']
    acc['dyslexia'] = "Police adaptée à la dyslexie"
    acc['dyslexiaDesc'] = "Utiliser une police conçue pour faciliter la lecture"
    acc['contrast'] = "Contraste élevé"
    acc['contrastDesc'] = "Augmenter le contraste des couleurs pour une meilleure visibilité"
    acc['falc'] = "Mode de lecture simplifié"
    acc['falcDesc'] = "Mise en page épurée et langage clair"
    acc['audioReading'] = "Lecture audio"
    acc['audioReadingDesc'] = "Lire le contenu à voix haute avec synthèse vocale"
    acc['adhd'] = "Mode concentration"
    acc['adhdDesc'] = "Réduire les distractions et mettre en évidence la ligne actuelle"
    acc['daltonism'] = "Filtre daltonisme"
    acc['daltonismDesc'] = "Ajuster les couleurs pour les déficiences visuelles"
    
with open('locales/fr.json', 'w') as f:
    json.dump(fr, f, indent=2)


# Update EN
with open('locales/en.json', 'r') as f:
    en = json.load(f)

if 'settings' not in en:
    en['settings'] = {}

if 'tabs' not in en['settings']:
    en['settings']['tabs'] = {
        "general": "General",
        "accessibility": "Accessibility",
        "appearance": "Appearance",
        "integrations": "Integrations",
        "notifications": "Notifications",
        "security": "Security",
        "data": "Data"
    }

# Move root accessibility to settings.accessibility
if 'accessibility' in en:
    en['settings']['accessibility'] = en.pop('accessibility')

if 'accessibility' not in en['settings']:
    en['settings']['accessibility'] = {}

en_acc = en['settings']['accessibility']
en_acc['title'] = "Accessibility"
en_acc['subtitle'] = "Adapt the app to your reading and viewing needs"
en_acc['dyslexia'] = "Dyslexia-friendly font"
en_acc['dyslexiaDesc'] = "Use a font designed for easier reading"
en_acc['contrast'] = "High contrast"
en_acc['contrastDesc'] = "Increase color contrast for better visibility"
en_acc['falc'] = "Easy-to-read mode"
en_acc['falcDesc'] = "Simplified layout and plain language"
en_acc['audioReading'] = "Audio reading"
en_acc['audioReadingDesc'] = "Read content aloud with text-to-speech"
en_acc['adhd'] = "Focus mode"
en_acc['adhdDesc'] = "Reduce distractions and highlight the current line"
en_acc['daltonism'] = "Color blindness filter"
en_acc['daltonismDesc'] = "Adjust colors for color vision deficiency"

with open('locales/en.json', 'w') as f:
    json.dump(en, f, indent=2)

print("Translations updated")
