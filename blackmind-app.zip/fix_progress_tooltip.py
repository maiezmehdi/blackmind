import re

with open('pages/ProgressPage.tsx', 'r') as f:
    content = f.read()

# Replace <Tooltip ... /> with a custom Tooltip content
tooltip_custom = """<Tooltip 
                  cursor={{ fill: 'transparent' }}
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-gemini-bg border border-gemini-border p-2 rounded-lg shadow-xl text-xs font-bold text-gemini-text">
                          {label} · {payload[0].value} h
                        </div>
                      );
                    }
                    return null;
                  }}
                />"""

content = re.sub(
    r'<Tooltip\s+contentStyle=\{[^}]+\}\s+itemStyle=\{[^}]+\}\s+/>',
    tooltip_custom,
    content
)

with open('pages/ProgressPage.tsx', 'w') as f:
    f.write(content)

print("patched tooltip in ProgressPage.tsx")
