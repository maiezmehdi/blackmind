import re

with open('pages/MarketplacePage.tsx', 'r') as f:
    content = f.read()

new_learn = """
                  {selectedCourse.modules.length > 0 && (
                    <div className="space-y-4 pt-4">
                      <h3 className="text-xs font-bold uppercase tracking-widest text-gemini-dim">{t('marketplace.whatYouLearn')}</h3>
                      <div className="grid grid-cols-1 gap-3">
                        {selectedCourse.modules.flatMap(m => m.lessons).slice(0, 5).map((les, i) => (
                          <div key={i} className={`flex items-center gap-3 p-3 rounded-xl bg-gemini-bg border border-gemini-border ${i >= 1 ? 'opacity-70' : ''}`}>
                            {i === 0 ? <CheckCircle2 size={16} className="text-green-500 shrink-0" /> : <span className="text-gemini-dim text-xs shrink-0">🔒</span>}
                            <span className="text-sm text-gemini-text">{les.title}</span>
                          </div>
                        ))}
                        {selectedCourse.modules.flatMap(m => m.lessons).length > 5 && (
                          <div className="text-xs text-gemini-dim italic">+ {selectedCourse.modules.flatMap(m => m.lessons).length - 5} autres leçons...</div>
                        )}
                      </div>
                    </div>
                  )}
"""

content = re.sub(
    r'<div className="space-y-4 pt-4">\s*<h3 className="text-xs font-bold uppercase tracking-widest text-gemini-dim">\{t\(\'marketplace\.whatYouLearn\'\)\}</h3>.*?</div>\s*</div>',
    new_learn.strip(),
    content,
    flags=re.DOTALL
)

with open('pages/MarketplacePage.tsx', 'w') as f:
    f.write(content)
print("patched modules")
