import json

with open('locales/fr.json', 'r') as f:
    fr = json.load(f)

# Typo fix and case
fr['marketplace']['buyNow'] = "Acheter maintenant"

# Generic delete confirmation
fr['common']['confirmDeleteTitle'] = "Supprimer « {title} » ?"
fr['common']['confirmDeleteCourse'] = "Supprimer le cours « {title} » ?"
fr['common']['confirmDeleteDesc'] = "Cette action est irréversible. Le contenu sera définitivement effacé."

# Workspaces vs Espaces
# In fr.json nav.workspaces = "Espaces". Let's check page title for workspaces.
if 'workspaces' in fr:
    fr['workspaces']['title'] = "Espaces"
else:
    fr['workspaces'] = {"title": "Espaces"}

with open('locales/fr.json', 'w') as f:
    json.dump(fr, f, indent=2)

with open('locales/en.json', 'r') as f:
    en = json.load(f)

en['marketplace']['buyNow'] = "Buy now"
en['common']['confirmDeleteTitle'] = "Delete \"{title}\"?"
en['common']['confirmDeleteCourse'] = "Delete the course \"{title}\"?"
en['common']['confirmDeleteDesc'] = "This action is irreversible. The content will be permanently lost."
if 'workspaces' not in en:
    en['workspaces'] = {}
en['workspaces']['title'] = "Workspaces"

with open('locales/en.json', 'w') as f:
    json.dump(en, f, indent=2)
print("patched copy JSON")
