import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

old_render = r'''           \) : generatedStory \? \(
             <div className="max-w-4xl mx-auto p-8 rounded-3xl border border-purple-500/30 bg-purple-500/5 space-y-8 shadow-2xl animate-in fade-in zoom-in-95 duration-500">
               <div className="space-y-2">
                 <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-400 text-\[10px\] font-bold uppercase tracking-widest border border-purple-500/30">
                   <BookOpen size=\{14\} /> Storytelling Mode
                 </div>
                 <h1 className="text-4xl md:text-5xl font-bold font-outfit text-gemini-accent tracking-tight">\{generatedStory\.title\}</h1>
                 <p className="text-xl text-gemini-dim">\{generatedStory\.logline\}</p>
               </div>
               <div className="space-y-6">
                 \{generatedStory\.scenes && generatedStory\.scenes\.map\(\(scene: any, idx: number\) => \(
                   <div key=\{idx\} className="p-6 rounded-2xl bg-gemini-surface/80 border border-gemini-border shadow-sm space-y-4">
                     <div className="flex items-center justify-between border-b border-gemini-border pb-4">
                       <h3 className="font-bold text-lg text-gemini-text">\{scene\.title\}</h3>
                       <span className="text-xs font-mono text-purple-400 bg-purple-500/10 px-2 py-1 rounded-lg border border-purple-500/20">\{scene\.setting\}</span>
                     </div>
                     <p className="text-gemini-dim font-medium leading-relaxed">\{scene\.action\}</p>
                     \{scene\.characters && scene\.characters\.length > 0 && \(
                       <div className="flex flex-wrap gap-2 pt-2">
                         \{scene\.characters\.map\(\(char: string, i: number\) => \(
                           <span key=\{i\} className="text-\[10px\] font-bold uppercase tracking-widest bg-gemini-bg text-gemini-dim px-3 py-1 rounded-full border border-gemini-border">
                             \{char\}
                           </span>
                         \)\)\}
                       </div>
                     \)\}
                   </div>
                 \)\)\}
               </div>
             </div>'''

new_render = r'''           ) : generatedStory ? (
             <div className="max-w-4xl mx-auto p-6 md:p-10 rounded-[3rem] border border-purple-500/20 bg-gradient-to-b from-purple-500/10 to-transparent space-y-12 shadow-2xl animate-in fade-in zoom-in-95 duration-500">
               <div className="space-y-6 text-center">
                 <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-500/10 text-purple-400 text-[10px] font-black uppercase tracking-[0.2em] border border-purple-500/20 shadow-sm">
                   <BookOpen size={14} className="animate-pulse" /> Storytelling Mode
                 </div>
                 <h1 className="text-4xl md:text-6xl font-black font-outfit text-gemini-accent tracking-tight leading-tight" contentEditable suppressContentEditableWarning onBlur={(e) => setGeneratedStory({...generatedStory, title: e.currentTarget.textContent || ''})}>{generatedStory.title}</h1>
                 <p className="text-xl md:text-2xl text-gemini-text/80 font-light leading-relaxed max-w-2xl mx-auto" contentEditable suppressContentEditableWarning onBlur={(e) => setGeneratedStory({...generatedStory, logline: e.currentTarget.textContent || ''})}>{generatedStory.logline}</p>
               </div>
               
               <div className="flex items-center justify-center gap-4 border-t border-gemini-border/50 pt-8 pb-4">
                  <div className="px-4 py-2 rounded-2xl bg-gemini-surface border border-gemini-border flex items-center gap-3">
                    <span className="text-[10px] font-bold text-gemini-dim uppercase tracking-widest">Scenes</span>
                    <span className="text-sm font-black text-gemini-accent">{generatedStory.scenes?.length || 0}</span>
                  </div>
                  <button className="px-4 py-2 bg-purple-500 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-purple-600 transition-colors shadow-lg flex items-center gap-2">
                    <Download size={14} /> Exporter le script
                  </button>
               </div>

               <div className="space-y-8">
                 {generatedStory.scenes && generatedStory.scenes.map((scene: any, idx: number) => (
                   <div key={idx} className="group relative p-6 md:p-8 rounded-[2rem] bg-gemini-surface border border-gemini-border shadow-sm hover:shadow-xl hover:border-purple-500/30 transition-all duration-300">
                     <div className="absolute -left-3 -top-3 w-8 h-8 rounded-full bg-gemini-bg border border-gemini-border flex items-center justify-center text-xs font-black text-gemini-dim shadow-sm group-hover:text-purple-400 group-hover:border-purple-400/50 transition-colors">
                       {idx + 1}
                     </div>
                     <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-6 border-b border-gemini-border/50">
                       <h3 className="font-bold text-xl text-gemini-text" contentEditable suppressContentEditableWarning onBlur={(e) => {
                         const newScenes = [...generatedStory.scenes];
                         newScenes[idx].title = e.currentTarget.textContent || '';
                         setGeneratedStory({...generatedStory, scenes: newScenes});
                       }}>{scene.title}</h3>
                       <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-gemini-bg border border-gemini-border">
                         <Camera size={14} className="text-gemini-dim" />
                         <span className="text-[10px] font-mono text-purple-400 font-bold tracking-wider" contentEditable suppressContentEditableWarning onBlur={(e) => {
                           const newScenes = [...generatedStory.scenes];
                           newScenes[idx].setting = e.currentTarget.textContent || '';
                           setGeneratedStory({...generatedStory, scenes: newScenes});
                         }}>{scene.setting}</span>
                       </div>
                     </div>
                     
                     <div className="relative">
                       <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-purple-500/20 to-transparent rounded-full"></div>
                       <p className="text-lg text-gemini-dim font-medium leading-relaxed pl-6" contentEditable suppressContentEditableWarning onBlur={(e) => {
                         const newScenes = [...generatedStory.scenes];
                         newScenes[idx].action = e.currentTarget.textContent || '';
                         setGeneratedStory({...generatedStory, scenes: newScenes});
                       }}>{scene.action}</p>
                     </div>
                     
                     {scene.characters && scene.characters.length > 0 && (
                       <div className="mt-8 pt-6 border-t border-gemini-border/30 flex flex-wrap gap-2 items-center">
                         <span className="text-[10px] font-bold text-gemini-dim uppercase tracking-widest mr-2"><User size={12} className="inline mr-1" /> Casting :</span>
                         {scene.characters.map((char: string, i: number) => (
                           <span key={i} className="text-xs font-bold bg-gemini-bg text-gemini-text px-3 py-1.5 rounded-xl border border-gemini-border shadow-sm">
                             {char}
                           </span>
                         ))}
                       </div>
                     )}
                   </div>
                 ))}
               </div>
             </div>'''

content = re.sub(old_render, new_render, content)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
