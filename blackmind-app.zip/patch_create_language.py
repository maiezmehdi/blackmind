import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

# State
content = content.replace(
    'const [isStorytellingMode, setIsStorytellingMode] = useState(false);',
    'const [isStorytellingMode, setIsStorytellingMode] = useState(false);\n  const [contentLanguage, setContentLanguage] = useState("fr");'
)

# API Calls
content = content.replace(
    'generateStorytellingStructure(activePrompt, isThinkingMode)',
    'generateStorytellingStructure(activePrompt, isThinkingMode, contentLanguage)'
)
content = content.replace(
    'generateCourseStructure(activePrompt, isThinkingMode)',
    'generateCourseStructure(activePrompt, isThinkingMode, contentLanguage)'
)

# UI addition in the chat options
lang_ui = """
                          <div className="px-2 py-1.5 flex items-center justify-between border-b border-gemini-border/50 mb-1">
                            <span className="text-[10px] font-bold text-gemini-dim uppercase tracking-widest">{t('settings.language')} du contenu</span>
                            <div className="flex gap-1">
                              <button onClick={() => setContentLanguage('fr')} className={`px-2 py-1 text-[10px] font-bold rounded ${contentLanguage === 'fr' ? 'bg-gemini-accent text-gemini-bg' : 'text-gemini-dim hover:text-gemini-accent'}`}>FR</button>
                              <button onClick={() => setContentLanguage('en')} className={`px-2 py-1 text-[10px] font-bold rounded ${contentLanguage === 'en' ? 'bg-gemini-accent text-gemini-bg' : 'text-gemini-dim hover:text-gemini-accent'}`}>EN</button>
                            </div>
                          </div>
                          <button 
"""

content = content.replace('<button \n                            onClick={() => { setIsStorytellingMode', lang_ui + '\n                            onClick={() => { setIsStorytellingMode')

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
print("patched CreatePage language")
