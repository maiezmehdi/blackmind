import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

# 1. Inject the handleExportStory function
func_code = """
  const handleExportStory = () => {
    if (!generatedStory) return;
    let text = `# ${generatedStory.title}\\n\\n`;
    text += `**Logline:** ${generatedStory.logline}\\n\\n`;
    text += `---\\n\\n`;
    
    generatedStory.scenes?.forEach((scene: any, idx: number) => {
      text += `## Scene ${idx + 1}: ${scene.title}\\n`;
      text += `**Setting:** ${scene.setting}\\n\\n`;
      text += `${scene.action}\\n\\n`;
      if (scene.characters && scene.characters.length > 0) {
        text += `**Characters:** ${scene.characters.join(', ')}\\n\\n`;
      }
      text += `---\\n\\n`;
    });

    const blob = new Blob([text], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${generatedStory.title.replace(/\s+/g, '_').toLowerCase()}_script.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
"""

content = content.replace(
    "  const handleGenerateCourse = async (customPrompt?: string) => {",
    func_code + "\n  const handleGenerateCourse = async (customPrompt?: string) => {"
)

# 2. Bind it to the button
old_btn = '<button className="px-4 py-2 bg-purple-500 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-purple-600 transition-colors shadow-lg flex items-center gap-2">'
new_btn = '<button onClick={handleExportStory} className="px-4 py-2 bg-purple-500 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-purple-600 transition-colors shadow-lg flex items-center gap-2">'

content = content.replace(old_btn, new_btn)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
