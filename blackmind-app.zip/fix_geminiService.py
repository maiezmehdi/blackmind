import re

with open('services/geminiService.ts', 'r') as f:
    content = f.read()

# For generateCourseStructure
content = content.replace(
    'export const generateCourseStructure = async (prompt: string, thinking: boolean = false): Promise<string> => {',
    'export const generateCourseStructure = async (prompt: string, thinking: boolean = false, language: string = "fr"): Promise<string> => {'
)
content = content.replace(
    'MISSION : Génère une structure JSON pour un cours complet.',
    'MISSION : Génère une structure JSON pour un cours complet. TOUT le contenu généré (titres, modules, leçons, textes, quiz) DOIT ETRE redigé dans la langue spécifiée: ${language}.'
)

# For generateStorytellingStructure
content = content.replace(
    'export const generateStorytellingStructure = async (prompt: string, thinking: boolean = false): Promise<string> => {',
    'export const generateStorytellingStructure = async (prompt: string, thinking: boolean = false, language: string = "fr"): Promise<string> => {'
)
content = content.replace(
    'MISSION : Génère un JSON représentant le plan interactif d\'une expérience immersive.',
    'MISSION : Génère un JSON représentant le plan interactif d\'une expérience immersive. TOUT le contenu généré DOIT ETRE redigé dans la langue spécifiée: ${language}.'
)

with open('services/geminiService.ts', 'w') as f:
    f.write(content)
print("patched geminiService")
