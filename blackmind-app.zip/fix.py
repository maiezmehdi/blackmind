import re
with open('pages/SettingsPage.tsx', 'r') as f:
    content = f.read()

content = re.sub(r'(\s*\}\s*)+case \'appearance\':', r'\n      }\n      case \'appearance\':', content)

with open('pages/SettingsPage.tsx', 'w') as f:
    f.write(content)
