import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

# Add setGeneratedCourse(null) and setGeneratedStory(null) where appropriate
old_func = """      if (isStorytellingMode) {
        const response = await generateStorytellingStructure(activePrompt, isThinkingMode);
        const cleanResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
        let responseData = JSON.parse(cleanResponse);
        setGeneratedStory(responseData);
        setMessages(prev => [...prev, { role: 'assistant', content: "Storytelling structure generated.", timestamp: new Date() }]);
      } else {"""

new_func = """      if (isStorytellingMode) {
        const response = await generateStorytellingStructure(activePrompt, isThinkingMode);
        const cleanResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
        let responseData = JSON.parse(cleanResponse);
        setGeneratedCourse(null);
        setGeneratedStory(responseData);
        setMessages(prev => [...prev, { role: 'assistant', content: "Storytelling structure generated.", timestamp: new Date() }]);
      } else {"""

content = content.replace(old_func, new_func)

old_func2 = """        setGeneratedCourse(newCourse);
        setIsPublished(false);
        setMessages(prev => [...prev, { role: 'assistant', content: commentary, suggestions, timestamp: new Date() }]);"""

new_func2 = """        setGeneratedStory(null);
        setGeneratedCourse(newCourse);
        setIsPublished(false);
        setMessages(prev => [...prev, { role: 'assistant', content: commentary, suggestions, timestamp: new Date() }]);"""

content = content.replace(old_func2, new_func2)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
