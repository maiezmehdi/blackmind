import re

with open('store/useCourseStore.ts', 'r') as f:
    content = f.read()

# Add import
content = content.replace(
    "import { translations } from '../translations';",
    "import { translations } from '../translations';\nimport { useLanguage } from '../contexts/LanguageContext';"
)

# Fix type
content = content.replace(
    "t: (key: string) => string;",
    "t: (key: string, variables?: any) => string;"
)

# Inside CourseProvider, replace internal states
state_code = """  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('blackmind_lang') as Language) || 'fr';
  });"""
content = content.replace(state_code, "  const { language, setLanguage, t } = useLanguage();")

t_impl = """  const t = useCallback((key: string): string => {
    const keys = key.split('.');
    let value: any = translations[language];
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        return key; // Fallback
      }
    }
    return typeof value === 'string' ? value : key;
  }, [language]);"""

content = content.replace(t_impl, "")

with open('store/useCourseStore.ts', 'w') as f:
    f.write(content)
print("patched useCourseStore.ts")
