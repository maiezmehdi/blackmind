import re

with open('pages/HomePage.tsx', 'r') as f:
    content = f.read()

# Replace CourseCard static text
content = content.replace("{course.category || 'Général'}", "{course.category || t('common.general')}")
content = content.replace("Par {course.author || 'Anonyme'}", "{t('home.by')} {course.author || t('common.anonymous')}")

content = content.replace(
    "{course.modules?.length || 0} module{course.modules?.length > 1 ? 's' : ''}",
    "{course.modules?.length || 0} {course.modules?.length > 1 ? t('home.modulesCountPlural') : t('home.modulesCountSingular')}"
)

content = content.replace(
    "{course.progress || 0}% complété",
    "{course.progress || 0}% {t('home.completed')}"
)

# Replace Hero section static text
content = content.replace(
    "{language === 'fr' ? 'Transformez votre expertise en contenu qui' : 'Turn your expertise into content that'}",
    "{t('home.heroTitle1')}"
)

content = content.replace(
    "{language === 'fr' ? 'captive.' : 'captivates.'}",
    "{t('home.heroTitle2')}"
)

content = content.replace(
    "{language === 'fr' ? 'Générez des cours, des scripts et des histoires qui engagent votre audience — propulsés par l\\'intelligence artificielle.' : 'Generate courses, scripts, and stories that engage your audience — powered by artificial intelligence.'}",
    "{t('home.heroSubtitle')}"
)

# And make sure HomePage has `const { t } = useLanguage()` inside
if "const { language, t } = useLanguage();" not in content:
    content = content.replace("const { language } = useLanguage();", "const { t } = useLanguage();")

# Wait, `useCourseContext` already exports `t`. And previously we removed `t` from `useCourseStore`? No, wait. 
# Did we remove `t` from `useCourseStore.ts`?
# In `patch_remove_t.py` I removed `const t = useCallback...` inside `useCourseStore.ts`.
# But `CourseProvider` still returns `{ ... t }` because `useCourseContext` gets it from `useLanguage()`.
# Wait, let's verify if `useCourseStore` still exposes `t`.

with open('pages/HomePage.tsx', 'w') as f:
    f.write(content)
