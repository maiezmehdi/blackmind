import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

content = content.replace(
    '<div className={`absolute top-2 right-2 flex gap-1 transition-opacity bg-gemini-surface border border-gemini-border rounded-lg shadow-lg p-1 z-10 ${isPreviewMode ? \'hidden\' : \'opacity-0 group-hover/block:opacity-100\'}`}>',
    '<div className={`absolute -top-4 right-4 flex gap-1 transition-opacity bg-gemini-surface border border-gemini-border rounded-lg shadow-lg p-1 z-[100] ${isPreviewMode ? \'hidden\' : \'opacity-0 group-hover/block:opacity-100\'}`}>'
)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
print("patched toolbar")
