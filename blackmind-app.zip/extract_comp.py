import re

with open('pages/SettingsPage.tsx', 'r') as f:
    content = f.read()

# I will just rename `tAcc` to `t` inside that block. Since it's a block `{ ... }`, it creates a new scope.
# The outer `t` is shadowed within this block, which is perfectly valid TypeScript!

content = content.replace("const tAcc = (key: string) => t(`settings.accessibility.${key}`);", "const tAcc = (key: string) => t(`settings.accessibility.${key}`);\n        const tScoped = (key: string) => t(`settings.accessibility.${key}`);")
content = content.replace("tAcc(", "tScoped(")

# Actually, shadowing `t` is what the user asked for: `so each call is just t("title")`
# Let's see if we can safely rename `tScoped` to `t`. 
# First, change `const tScoped` to `const t = (key: string) => tGlobal(`settings.accessibility.${key}`);`
# But wait, we can just do:
# `const tScoped = ...`
# and replace `tScoped` with `t`. But how do we refer to the outer `t`? 
# We don't need to inside that block! All translations in that block are under `settings.accessibility`.
# Wait, are there any outer translations needed? Let's check!
