import fs from 'fs';

// simple regex to extract the object string is hard, let's just create a quick wrapper
const code = fs.readFileSync('translations.ts', 'utf8');
const objCode = code.replace('export const translations =', 'export default');
fs.writeFileSync('translations_temp.mjs', objCode);
