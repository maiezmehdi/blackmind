import re

with open('store/useCourseStore.ts', 'r') as f:
    content = f.read()

mock_google = """  const loginWithGoogle = useCallback(async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    const name = window.prompt("Nom d'utilisateur :", "Alexandre Dupont");
    if (!name) return; // Cancelled
    const user: UserProfile = {
      id: 'user-google-' + Math.random().toString(36).substr(2, 5),
      name: name,
      initials: name.substring(0,2).toUpperCase(),
      color: 'bg-gemini-dim',
      email: name.toLowerCase().replace(' ', '.') + '@gmail.com',
      subscription: 'free'
    };
    setCurrentUser(user);
  }, []);"""

content = re.sub(r'const loginWithGoogle = useCallback.*?setCurrentUser\(user\);\n\s*\}, \[\]\);', mock_google, content, flags=re.DOTALL)

with open('store/useCourseStore.ts', 'w') as f:
    f.write(content)
print("patched loginWithGoogle")
