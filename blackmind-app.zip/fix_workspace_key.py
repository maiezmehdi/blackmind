import json

with open('locales/fr.json', 'r') as f:
    fr = json.load(f)
if 'workspace' in fr:
    fr['workspace']['title'] = "Espaces"
else:
    fr['workspace'] = {"title": "Espaces"}
with open('locales/fr.json', 'w') as f:
    json.dump(fr, f, indent=2)

with open('locales/en.json', 'r') as f:
    en = json.load(f)
if 'workspace' in en:
    en['workspace']['title'] = "Workspaces"
else:
    en['workspace'] = {"title": "Workspaces"}
with open('locales/en.json', 'w') as f:
    json.dump(en, f, indent=2)
