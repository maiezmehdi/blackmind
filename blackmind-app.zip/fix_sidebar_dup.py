import re

with open('components/Layout/Sidebar.tsx', 'r') as f:
    content = f.read()

content = content.replace("  const { currentUser } = useCourseContext();\n  const { t } = useLanguage();", "  const { currentUser } = useCourseContext();")

with open('components/Layout/Sidebar.tsx', 'w') as f:
    f.write(content)
