import re

with open('pages/SettingsPage.tsx', 'r') as f:
    content = f.read()

# Fix the \'appearance\' syntax error
content = content.replace("      }\n      case \\'appearance\\':", "      case 'appearance':")
content = content.replace("      }\n      case 'appearance':", "      case 'appearance':")

# Now we need to close the `{` of `case 'accessibility': {`
# Where does case 'accessibility': return (...); end?
# It ends right before `case 'notifications':`

content = re.sub(r'(\s*case \'notifications\':)', r'\n      }\n\1', content)

with open('pages/SettingsPage.tsx', 'w') as f:
    f.write(content)

