with open('pages/SettingsPage.tsx', 'r') as f:
    content = f.read()

content = content.replace('{activeTab}</h1>', '{t(`settings.tabs.${activeTab}`)}</h1>')

with open('pages/SettingsPage.tsx', 'w') as f:
    f.write(content)
