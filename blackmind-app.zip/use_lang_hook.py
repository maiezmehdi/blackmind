import os
import re

files_to_update = [
    'components/Layout/Sidebar.tsx',
    'pages/HomePage.tsx',
    'components/Layout/Header.tsx',
    'App.tsx'
]

for file in files_to_update:
    with open(file, 'r') as f:
        content = f.read()
    
    # Ensure import { useLanguage }
    if 'useLanguage' not in content:
        content = content.replace("import { useCourseContext } from '../../store/useCourseStore';", "import { useCourseContext } from '../../store/useCourseStore';\nimport { useLanguage } from '../../contexts/LanguageContext';")
        content = content.replace("import { useCourseContext } from '../store/useCourseStore';", "import { useCourseContext } from '../store/useCourseStore';\nimport { useLanguage } from '../contexts/LanguageContext';")
    
    # In Sidebar.tsx
    if file == 'components/Layout/Sidebar.tsx':
        content = content.replace('const { currentUser } = useCourseContext();', 'const { currentUser } = useCourseContext();\n  const { t } = useLanguage();')
        
    # In App.tsx
    if file == 'App.tsx':
        content = content.replace('const { language, t } = useLanguage();', 'const { language, t } = useLanguage();\n')
        
    with open(file, 'w') as f:
        f.write(content)

print("done")
