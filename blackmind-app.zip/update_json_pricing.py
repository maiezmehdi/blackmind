import json

def update(file):
    with open(file, 'r') as f:
        data = json.load(f)
    if 'pricing' not in data:
        data['pricing'] = {}
    
    if file.endswith('fr.json'):
        data['pricing']['plan'] = "Plan"
        data['pricing']['free'] = "Gratuit"
    else:
        data['pricing']['plan'] = "Plan"
        data['pricing']['free'] = "Free"

    with open(file, 'w') as f:
        json.dump(data, f, indent=2)

update('locales/fr.json')
update('locales/en.json')
