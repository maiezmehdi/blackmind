import json

with open('locales/fr.json', 'r') as f:
    fr = json.load(f)

print(list(fr['settings'].keys()))
