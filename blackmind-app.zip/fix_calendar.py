import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

content = content.replace("icon: BookOpen, Calendar, prompt:", "icon: BookOpen, prompt:")
content = content.replace("icon: BookOpen, Calendar,", "icon: BookOpen,")

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
print("Done")
