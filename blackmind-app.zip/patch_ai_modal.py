import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

# AI modal replacement
content = content.replace(
    '<div className="relative w-full max-w-2xl bg-gemini-surface border border-gemini-border rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">',
    '<div className="relative w-full max-w-2xl glass-card rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh] bg-gemini-surface/80 backdrop-blur-3xl">'
)

# And the delete confirm modal also
content = content.replace(
    '<div className="relative w-full max-w-md bg-gemini-surface border border-gemini-border rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 p-6 flex flex-col text-center">',
    '<div className="relative w-full max-w-md glass-card bg-gemini-surface/80 backdrop-blur-3xl rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 p-8 flex flex-col text-center">'
)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
