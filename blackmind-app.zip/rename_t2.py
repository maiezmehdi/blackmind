import re

with open('pages/SettingsPage.tsx', 'r') as f:
    content = f.read()

content = content.replace("const tAcc = (key: string) => tGlobal(`settings.accessibility.${key}`);", "const t = (key: string) => tGlobal(`settings.accessibility.${key}`);")
content = content.replace("tAcc(", "t(")

with open('pages/SettingsPage.tsx', 'w') as f:
    f.write(content)
