import json

with open('locales/fr.json', 'r') as f:
    fr = json.load(f)

fr['categories'] = {
    "all": "Tous",
    "favorites": "Favoris",
    "ai": "IA & Data",
    "dev": "Développement",
    "design": "Design",
    "business": "Business",
    "languages": "Langues",
    "science": "Sciences"
}

with open('locales/fr.json', 'w') as f:
    json.dump(fr, f, indent=2)

with open('locales/en.json', 'r') as f:
    en = json.load(f)

en['categories'] = {
    "all": "All",
    "favorites": "Favorites",
    "ai": "AI & Data",
    "dev": "Development",
    "design": "Design",
    "business": "Business",
    "languages": "Languages",
    "science": "Science"
}

with open('locales/en.json', 'w') as f:
    json.dump(en, f, indent=2)

