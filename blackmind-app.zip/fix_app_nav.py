import re

with open('App.tsx', 'r') as f:
    content = f.read()

# Make sure we use t from useLanguage
if 'const { language } = useLanguage();' in content:
    content = content.replace('const { language } = useLanguage();', 'const { language, t: tLang } = useLanguage();')

# App.tsx is using `const { t } = useCourseContext();` probably wrongly. Let's fix that.
content = content.replace('const { t } = useCourseContext();', '')
content = content.replace('const { language } = useLanguage();', 'const { language, t } = useLanguage();')

content = re.sub(
    r'<span className="text-\[9px\] font-bold uppercase tracking-widest">\{language === \'fr\' \? \'Créer\' : \'Create\'\}</span>',
    r'<span className="text-[9px] font-bold uppercase tracking-widest">{t(\'nav.create\')}</span>',
    content
)
content = re.sub(
    r'<span className="text-\[9px\] font-bold uppercase tracking-widest">\{language === \'fr\' \? \'Market\' : \'Market\'\}</span>',
    r'<span className="text-[9px] font-bold uppercase tracking-widest">{t(\'nav.marketplace\')}</span>',
    content
)
content = re.sub(
    r'<span className="text-\[9px\] font-bold uppercase tracking-widest">\{language === \'fr\' \? \'Espaces\' : \'Workspaces\'\}</span>',
    r'<span className="text-[9px] font-bold uppercase tracking-widest">{t(\'nav.workspaces\')}</span>',
    content
)
content = re.sub(
    r'<span className="text-\[9px\] font-bold uppercase tracking-widest">\{language === \'fr\' \? \'Progression\' : \'Progress\'\}</span>',
    r'<span className="text-[9px] font-bold uppercase tracking-widest">{t(\'nav.progress\')}</span>',
    content
)
content = re.sub(
    r'<span className="text-\[9px\] font-bold uppercase tracking-widest">\{language === \'fr\' \? \'Paramètres\' : \'Settings\'\}</span>',
    r'<span className="text-[9px] font-bold uppercase tracking-widest">{t(\'nav.settings\')}</span>',
    content
)

with open('App.tsx', 'w') as f:
    f.write(content)

print("patched App.tsx nav")
