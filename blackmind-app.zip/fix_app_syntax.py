with open('App.tsx', 'r') as f:
    content = f.read()

content = content.replace(r"t(\'nav", "t('nav")
content = content.replace(r"\')}", "')}")

with open('App.tsx', 'w') as f:
    f.write(content)
