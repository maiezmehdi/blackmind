import re

with open('pages/MarketplacePage.tsx', 'r') as f:
    content = f.read()

# Fix Modal detail metrics
content = content.replace(
    '<span className="text-white/70 text-xs">({selectedCourse.students} {t(\'marketplace.reviews\')})</span>',
    '<span className="text-white/70 text-xs">({Math.floor(selectedCourse.students! / 4)} {t(\'marketplace.reviews\')}) · {selectedCourse.students} {t(\'marketplace.students\')}</span>'
)

# Fix Featured card metrics (currently it has just rating and students)
content = content.replace(
    '<span className="text-sm font-bold text-white">{featuredCourse.rating}</span>',
    '<span className="text-sm font-bold text-white">{featuredCourse.rating} <span className="font-normal opacity-70">({Math.floor(featuredCourse.students! / 4)})</span></span>'
)

# Fix grid cards metrics
content = content.replace(
    '<span className="text-xs font-bold text-gemini-text">{course.rating}</span>',
    '<span className="text-xs font-bold text-gemini-text">{course.rating} <span className="font-normal text-gemini-dim">({Math.floor(course.students! / 4)})</span></span>'
)

with open('pages/MarketplacePage.tsx', 'w') as f:
    f.write(content)

print("patched metrics")
