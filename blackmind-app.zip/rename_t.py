import re

with open('pages/SettingsPage.tsx', 'r') as f:
    content = f.read()

# Rename destructured t to tGlobal
content = content.replace("const { language, setLanguage, t } = useLanguage();", "const { language, setLanguage, t: tGlobal } = useLanguage();\n  const t = tGlobal;")

# In the case block, we redefine `t`
content = content.replace("const tAcc = (key: string) => t(`settings.accessibility.${key}`);", "const tAcc = (key: string) => tGlobal(`settings.accessibility.${key}`);")

content = content.replace("tScoped(", "t(")

with open('pages/SettingsPage.tsx', 'w') as f:
    f.write(content)
