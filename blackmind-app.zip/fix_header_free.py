with open('components/Layout/Header.tsx', 'r') as f:
    content = f.read()

content = content.replace(
    "{currentUser.subscription === 'free' ? 'Free' : currentUser.subscription === 'creator' ? 'Creator' : 'Architect'}",
    "{currentUser.subscription === 'free' ? t('pricing.free') : currentUser.subscription === 'creator' ? 'Creator' : 'Architect'}"
)

with open('components/Layout/Header.tsx', 'w') as f:
    f.write(content)
