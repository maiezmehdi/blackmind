with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

old_block = """                        {m.suggestions.map((suggestion: string, sIdx: number) => (
                          <button 
                            key={sIdx}
                            onClick={() => handleGenerateCourse(suggestion)}
                            className="px-4 py-2.5 bg-gemini-surface border border-gemini-border rounded-full text-[10px] font-bold tracking-wider text-gemini-dim hover:text-gemini-accent hover:border-gemini-accent hover:shadow-md hover:-translate-y-0.5 transition-all shadow-sm whitespace-nowrap group/sug"
                          >
                            <Plus size={12} className="inline mr-1 group-hover/sug:rotate-90 transition-transform" /> {suggestion}
                          </button>
                        ))}"""

new_block = """                        {m.suggestions.map((suggestion: string, sIdx: number) => {
                          if (suggestion === '__ACTION_PREVIEW__') {
                            return (
                              <button
                                key={sIdx}
                                onClick={() => setView('preview')}
                                className="px-6 py-2.5 bg-gemini-accent text-gemini-bg rounded-full text-[10px] font-bold tracking-wider hover:scale-105 transition-all shadow-lg whitespace-nowrap"
                              >
                                {t('create.viewResult') || 'Voir le résultat ->'}
                              </button>
                            );
                          }
                          return (
                          <button 
                            key={sIdx}
                            onClick={() => handleGenerateCourse(suggestion)}
                            className="px-4 py-2.5 bg-gemini-surface border border-gemini-border rounded-full text-[10px] font-bold tracking-wider text-gemini-dim hover:text-gemini-accent hover:border-gemini-accent hover:shadow-md hover:-translate-y-0.5 transition-all shadow-sm whitespace-nowrap group/sug"
                          >
                            <Plus size={12} className="inline mr-1 group-hover/sug:rotate-90 transition-transform" /> {suggestion}
                          </button>
                        )})}"""

content = content.replace(old_block, new_block)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
