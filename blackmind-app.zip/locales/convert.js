const fs = require('fs');

// Note: Because it's typescript, we'll strip the export and parse it as a module
const code = fs.readFileSync('translations.ts', 'utf8');
const objCode = code.replace('export const translations = ', 'module.exports = ');
fs.writeFileSync('translations.js', objCode);
const translations = require('./translations.js');
fs.writeFileSync('locales/fr.json', JSON.stringify(translations.fr, null, 2));
fs.writeFileSync('locales/en.json', JSON.stringify(translations.en, null, 2));
