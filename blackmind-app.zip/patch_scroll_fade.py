import re

# Patch SettingsPage
with open('pages/SettingsPage.tsx', 'r') as f:
    content = f.read()

content = content.replace(
    '<nav className="flex md:flex-col gap-2 overflow-x-auto no-scrollbar pb-2 sticky top-24">',
    '<div className="relative md:static md:w-full"><div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-gemini-bg to-transparent pointer-events-none md:hidden z-10" /><nav className="flex md:flex-col gap-2 overflow-x-auto no-scrollbar pb-2 sticky top-24 snap-x snap-mandatory pr-8">'
)
content = content.replace(
    'onClick={() => setActiveTab(tab.id)}',
    'onClick={() => setActiveTab(tab.id)}\n                style={{ scrollSnapAlign: "start" }}'
)
# Close the div wrapper for the nav. Need to find where nav ends
# It's at </nav>. Wait, let's just do regex or replace.
content = content.replace(
    '</nav>',
    '</nav></div>'
)

with open('pages/SettingsPage.tsx', 'w') as f:
    f.write(content)

# Patch MarketplacePage
with open('pages/MarketplacePage.tsx', 'r') as f:
    content = f.read()

content = content.replace(
    '<div className="flex gap-3 overflow-x-auto pb-4 no-scrollbar -mx-4 px-4">',
    '<div className="relative -mx-4 px-4"><div className="absolute right-0 top-0 bottom-4 w-12 bg-gradient-to-l from-gemini-bg to-transparent pointer-events-none z-10" /><div className="flex gap-3 overflow-x-auto pb-4 no-scrollbar snap-x snap-mandatory pr-12">'
)
content = content.replace(
    'onClick={() => setSelectedCategoryKey(catKey)}',
    'onClick={() => setSelectedCategoryKey(catKey)}\n              style={{ scrollSnapAlign: "start" }}'
)
# Close the div wrapper. The original had `<div className="flex gap-3...` which we replaced with two divs. So we need an extra `</div>`
# It's `))} </div>`
content = content.replace(
    '            </button>\n          ))}\n        </div>',
    '            </button>\n          ))}\n        </div></div>'
)

with open('pages/MarketplacePage.tsx', 'w') as f:
    f.write(content)

print("patched scrolling tabs")
