with open('pages/MarketplacePage.tsx', 'r') as f:
    content = f.read()

content = content.replace("import { useCourseContext } from '../store/useCourseStore';", "import { useCourseContext } from '../store/useCourseStore';\nimport { useLanguage } from '../contexts/LanguageContext';")

def_price = """  const { language } = useLanguage();
  const formatPrice = (priceStr: string | undefined) => {
    if (!priceStr) return priceStr;
    if (priceStr === 'Gratuit' || priceStr === 'Free') return t('marketplace.free');
    const num = parseFloat(priceStr);
    if (isNaN(num)) return priceStr;
    return new Intl.NumberFormat(language === 'fr' ? 'fr-FR' : 'en-US', { style: 'currency', currency: 'EUR' }).format(num);
  };
"""

content = content.replace("const { t, courses, buyCourse } = useCourseContext();", "const { t, courses, buyCourse } = useCourseContext();\n" + def_price)

with open('pages/MarketplacePage.tsx', 'w') as f:
    f.write(content)
