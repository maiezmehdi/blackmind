import re

with open('components/Layout/Sidebar.tsx', 'r') as f:
    content = f.read()

content = content.replace('const { language } = useLanguage();', 'const { language, t } = useLanguage();')
content = content.replace('const { t, currentUser } = useCourseContext();', 'const { currentUser } = useCourseContext();')

content = re.sub(
    r"label=\{language === 'fr' \? 'Explorer' : 'Explore'\}",
    r"label={t('nav.explorer')}",
    content
)
content = re.sub(
    r"label=\{language === 'fr' \? 'Créer' : 'Create'\}",
    r"label={t('nav.create')}",
    content
)
content = re.sub(
    r"label=\{language === 'fr' \? 'Marketplace' : 'Marketplace'\}",
    r"label={t('nav.marketplace')}",
    content
)
content = re.sub(
    r"label=\{language === 'fr' \? 'Progression' : 'Progress'\}",
    r"label={t('nav.progress')}",
    content
)
content = re.sub(
    r"label=\{language === 'fr' \? 'Espaces' : 'Workspaces'\}",
    r"label={t('nav.workspaces')}",
    content
)
content = re.sub(
    r"label=\{language === 'fr' \? 'Paramètres' : 'Settings'\}",
    r"label={t('nav.settings')}",
    content
)

# Plan Gratuit
content = content.replace('>Plan<', '>{t("pricing.plan")}<')
content = content.replace('>Gratuit<', '>{t("pricing.free")}<')


with open('components/Layout/Sidebar.tsx', 'w') as f:
    f.write(content)

print("patched Sidebar.tsx")
