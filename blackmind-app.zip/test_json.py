import json

with open('locales/fr.json', 'r') as f:
    fr = json.load(f)

print("fr settings keys:", list(fr.get('settings', {}).keys()))

with open('locales/en.json', 'r') as f:
    en = json.load(f)

print("en settings keys:", list(en.get('settings', {}).keys()))
if 'accessibility' in en:
    print("en accessibility exists at root")

