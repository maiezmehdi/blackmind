import re

with open('store/useCourseStore.ts', 'r') as f:
    content = f.read()

# Remove the t definition
content = re.sub(r'\s*const t = useCallback\(\(key: string\): string => \{.*?\},\s*\[language\]\);', '', content, flags=re.DOTALL)

with open('store/useCourseStore.ts', 'w') as f:
    f.write(content)
