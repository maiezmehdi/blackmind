import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

target = r'<div className=\{`p-4 border-t border-gemini-border bg-gemini-bg relative z-30 space-y-3`\}>'
replacement = r"""<div className={`p-4 border-t border-gemini-border bg-gemini-bg relative z-30 space-y-3`}>
                {isStorytellingMode && (
                  <div className="flex items-center gap-2 mb-2 animate-in fade-in slide-in-from-bottom-2 duration-300">
                    <div className="px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-[10px] font-bold uppercase tracking-widest border border-purple-500/20 flex items-center gap-1.5 shadow-sm">
                      <BookOpen size={12} />
                      Mode Storytelling
                      <button onClick={() => setIsStorytellingMode(false)} className="ml-1 hover:text-purple-300 hover:bg-purple-500/20 rounded-full p-0.5 transition-colors">
                        <X size={10} />
                      </button>
                    </div>
                  </div>
                )}"""

content = re.sub(target, replacement, content)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
