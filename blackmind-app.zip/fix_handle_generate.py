import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

pattern = r"""    try \{\s*const response = await generateCourseStructure.*?setMessages\(prev => \[\.\.\.prev, \{ role: 'assistant', content: commentary, suggestions, timestamp: new Date\(\) \}\]\);\s*\} catch \(err: any\) \{"""

replacement = """    try {
      if (isStorytellingMode) {
        const response = await generateStorytellingStructure(activePrompt, isThinkingMode);
        const cleanResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
        let responseData = JSON.parse(cleanResponse);
        setGeneratedCourse(null);
        setGeneratedStory(responseData);
        setMessages(prev => [...prev, { role: 'assistant', content: "Storytelling structure generated.", timestamp: new Date() }]);
      } else {
        const response = await generateCourseStructure(activePrompt, isThinkingMode);
        const cleanResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
        let responseData = JSON.parse(cleanResponse);

        const courseData = responseData.course || responseData;
        const commentary = responseData.commentary || "Architecture générée.";
        const suggestions = responseData.suggestions || [];

        const newCourse: Course = {
          id: Math.random().toString(36).substr(2, 9),
          ...courseData,
          image: `https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=1200`,
          progress: 0,
          author: currentUser?.name || 'Anonyme',
          category: courseData.category || 'Général',
          collaborators: []
        };

        setGeneratedStory(null);
        setGeneratedCourse(newCourse);
        setIsPublished(false);
        setMessages(prev => [...prev, { role: 'assistant', content: commentary, suggestions, timestamp: new Date() }]);
      }
    } catch (err: any) {"""

content = re.sub(pattern, replacement, content, flags=re.DOTALL)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
