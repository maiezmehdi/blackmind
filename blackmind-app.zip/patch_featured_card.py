import re

with open('pages/MarketplacePage.tsx', 'r') as f:
    content = f.read()

# Replace the featured card rendering
old_card = """      {selectedCategoryKey === "all" && !searchTerm && featuredCourse && (
        <section className="relative rounded-[3rem] overflow-hidden group shadow-2xl border border-gemini-border">
          <div className="absolute inset-0">
            <img 
              src={featuredCourse.image} 
              alt={featuredCourse.title} 
              onError={(e) => handleImageError(e, featuredCourse.title)}
              className="w-full h-full object-cover transition-all duration-1000 group-hover:scale-105" 
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black via-black/60 to-transparent"></div>
          </div>
          <div className="relative p-8 md:p-16 flex flex-col justify-center gap-6 max-w-2xl">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 px-4 py-1.5 rounded-full w-fit">
                <Sparkles size={14} className="text-white animate-pulse" />
                <span className="text-[10px] font-bold text-white uppercase tracking-widest">{t('marketplace.featured')}</span>
              </div>
              {featuredCourse.price === 'Gratuit' && (
                 <div className="flex items-center gap-2 bg-green-500/20 backdrop-blur-md border border-green-500/30 px-4 py-1.5 rounded-full w-fit">
                    <Award size={14} className="text-green-400" />
                    <span className="text-[10px] font-bold text-green-400 uppercase tracking-widest">{t('marketplace.free')}</span>
                 </div>
              )}
            </div>
            <h2 className="text-3xl md:text-5xl font-bold font-outfit text-white leading-tight">{featuredCourse.title}</h2>
            <p className="text-neutral-300 text-lg leading-relaxed line-clamp-3">{featuredCourse.description}</p>
            <div className="flex items-center gap-8 py-2">
              <div className="flex items-center gap-2">
                <Star size={16} className="text-white" fill="white" />
                <span className="text-sm font-bold text-white">{featuredCourse.rating} <span className="font-normal opacity-70">({Math.floor(featuredCourse.students! / 4)})</span></span>
              </div>
              <div className="flex items-center gap-2">
                <Users size={16} className="text-neutral-400" />
                <span className="text-sm font-medium text-neutral-400">{featuredCourse.students} {t('marketplace.students')}</span>
              </div>
            </div>
            <div className="flex items-center gap-4 pt-4">
              <button 
                onClick={() => openCourseModal(featuredCourse)}
                className="px-10 py-4 bg-white text-black rounded-2xl font-bold text-xs uppercase tracking-[0.2em] shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center gap-3"
              >
                <ShoppingCart size={18} /> {t('marketplace.buy')} — {formatPrice(featuredCourse.price)}
              </button>
              <button className="p-4 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl text-white hover:bg-white/10 transition-all">
                <Heart size={20} />
              </button>
            </div>
          </div>
        </section>
      )}"""

new_card = """      {selectedCategoryKey === "all" && !searchTerm && featuredCourse && (
        <section className="rounded-[3rem] overflow-hidden group shadow-2xl border border-gemini-border bg-gemini-surface flex flex-col md:flex-row">
          <div className="w-full md:w-1/2 relative h-[300px] md:h-auto overflow-hidden">
            <img 
              src={featuredCourse.image} 
              alt={featuredCourse.title} 
              onError={(e) => handleImageError(e, featuredCourse.title)}
              className="w-full h-full object-cover transition-all duration-1000 group-hover:scale-105" 
            />
          </div>
          <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col justify-center gap-6">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-gemini-accent/10 border border-gemini-accent/20 px-4 py-1.5 rounded-full w-fit">
                <Sparkles size={14} className="text-gemini-accent animate-pulse" />
                <span className="text-[10px] font-bold text-gemini-accent uppercase tracking-widest">{t('marketplace.featured')}</span>
              </div>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold font-outfit text-gemini-accent leading-tight">{featuredCourse.title}</h2>
            <p className="text-gemini-dim text-base leading-relaxed line-clamp-3">{featuredCourse.description}</p>
            <div className="flex items-center gap-8 py-2">
              <div className="flex items-center gap-2">
                <Star size={16} className="text-amber-500" fill="currentColor" />
                <span className="text-sm font-bold text-gemini-text">{featuredCourse.rating} <span className="font-normal opacity-70">({Math.floor(featuredCourse.students! / 4)})</span></span>
              </div>
              <div className="flex items-center gap-2">
                <Users size={16} className="text-gemini-dim" />
                <span className="text-sm font-medium text-gemini-dim">{featuredCourse.students} {t('marketplace.students')}</span>
              </div>
            </div>
            <div className="flex items-center gap-4 pt-4 mt-auto">
              <button 
                onClick={() => openCourseModal(featuredCourse)}
                className="flex-1 px-8 py-4 bg-gemini-accent text-gemini-bg rounded-2xl font-bold text-xs uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-3"
              >
                <ShoppingCart size={18} /> {t('marketplace.buy')} — {formatPrice(featuredCourse.price)}
              </button>
              <button className="p-4 bg-gemini-bg border border-gemini-border rounded-2xl text-gemini-dim hover:text-red-500 hover:border-red-500/30 transition-all">
                <Heart size={20} />
              </button>
            </div>
          </div>
        </section>
      )}"""

content = content.replace(old_card, new_card)

with open('pages/MarketplacePage.tsx', 'w') as f:
    f.write(content)

print("patched featured card")
