import json

with open('locales/en.json', 'r') as f:
    en = json.load(f)

if 'suggestions' not in en['create']:
    en['create']['suggestions'] = {
        "marketing": "Create a marketing course",
        "python": "Teach Python basics",
        "photography": "Design a photography workshop"
    }

with open('locales/en.json', 'w') as f:
    json.dump(en, f, indent=2)

with open('locales/fr.json', 'r') as f:
    fr = json.load(f)

if 'suggestions' not in fr['create']:
    fr['create']['suggestions'] = {
        "marketing": "Créer un cours de marketing",
        "python": "Enseigner les bases de Python",
        "photography": "Concevoir un atelier photo"
    }

with open('locales/fr.json', 'w') as f:
    json.dump(fr, f, indent=2)

print("Locales updated")
