import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

# Add import
content = content.replace(
    "import { generateCourseStructure, refineContent, generateAiBlock, generateSpeech } from '../services/geminiService';",
    "import { generateCourseStructure, generateStorytellingStructure, refineContent, generateAiBlock, generateSpeech } from '../services/geminiService';"
)

# Modify handleGenerateCourse
old_func = """    try {
      const response = await generateCourseStructure(activePrompt, isThinkingMode);
      const cleanResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
      let responseData = JSON.parse(cleanResponse);

      const courseData = responseData.course || responseData;
      const commentary = responseData.commentary || "Architecture générée.";
      const suggestions = responseData.suggestions || [];

      const newCourse: Course = {
        id: Math.random().toString(36).substr(2, 9),
        ...courseData,
        image: `https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=1200`,
        progress: 0,
        author: currentUser?.name || 'Anonyme',
        category: courseData.category || 'Général',
        collaborators: []
      };

      setGeneratedCourse(newCourse);
      setIsPublished(false);
      setMessages(prev => [...prev, { role: 'assistant', content: commentary, suggestions, timestamp: new Date() }]);
    } catch (err: any) {"""

new_func = """    try {
      if (isStorytellingMode) {
        const response = await generateStorytellingStructure(activePrompt, isThinkingMode);
        const cleanResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
        let responseData = JSON.parse(cleanResponse);
        setGeneratedStory(responseData);
        setMessages(prev => [...prev, { role: 'assistant', content: "Storytelling structure generated.", timestamp: new Date() }]);
      } else {
        const response = await generateCourseStructure(activePrompt, isThinkingMode);
        const cleanResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
        let responseData = JSON.parse(cleanResponse);

        const courseData = responseData.course || responseData;
        const commentary = responseData.commentary || "Architecture générée.";
        const suggestions = responseData.suggestions || [];

        const newCourse: Course = {
          id: Math.random().toString(36).substr(2, 9),
          ...courseData,
          image: `https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=1200`,
          progress: 0,
          author: currentUser?.name || 'Anonyme',
          category: courseData.category || 'Général',
          collaborators: []
        };

        setGeneratedCourse(newCourse);
        setIsPublished(false);
        setMessages(prev => [...prev, { role: 'assistant', content: commentary, suggestions, timestamp: new Date() }]);
      }
    } catch (err: any) {"""

content = content.replace(old_func, new_func)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
