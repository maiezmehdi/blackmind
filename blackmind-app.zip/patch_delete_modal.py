import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

content = content.replace(
    "const [deleteConfirm, setDeleteConfirm] = useState<{ show: boolean, type: string, params: any }>({ show: false, type: '', params: {} });",
    "const [deleteConfirm, setDeleteConfirm] = useState<{ show: boolean, type: string, params: any, title?: string }>({ show: false, type: '', params: {}, title: '' });"
)

# Update the setDeleteConfirm calls to include a title
content = re.sub(
    r"setDeleteConfirm\(\{ show: true, type: 'course', params: \{\} \}\);",
    r"setDeleteConfirm({ show: true, type: 'course', params: {}, title: generatedCourse?.title || '' });",
    content
)
content = re.sub(
    r"setDeleteConfirm\(\{ show: true, type: 'module', params: \{ moduleId: mod\.id \} \}\)",
    r"setDeleteConfirm({ show: true, type: 'module', params: { moduleId: mod.id }, title: mod.title })",
    content
)
content = re.sub(
    r"setDeleteConfirm\(\{ show: true, type: 'lesson', params: \{ modId: mod\.id, lesId: lesson\.id \} \}\)",
    r"setDeleteConfirm({ show: true, type: 'lesson', params: { modId: mod.id, lesId: lesson.id }, title: lesson.title })",
    content
)
content = re.sub(
    r"setDeleteConfirm\(\{ show: true, type: 'block', params: \{ modId: mod\.id, lesId: lesson\.id, blockId: block\.id \} \}\)",
    r"setDeleteConfirm({ show: true, type: 'block', params: { modId: mod.id, lesId: lesson.id, blockId: block.id }, title: 'Bloc de contenu' })",
    content
)
# For the toolbar
content = re.sub(
    r"setDeleteConfirm\(\{ show: true, type: 'block', params: \{ modId: selectionContext\.modId, lesId: selectionContext\.lesId, blockId: selectionContext\.blockId \} \}\)",
    r"setDeleteConfirm({ show: true, type: 'block', params: { modId: selectionContext.modId, lesId: selectionContext.lesId, blockId: selectionContext.blockId }, title: 'Sélection' })",
    content
)

# Render the dynamic title
content = content.replace(
    "<h3 className=\"text-2xl font-bold font-outfit text-gemini-text\">{t('common.confirmDeleteTitle')}</h3>",
    "<h3 className=\"text-2xl font-bold font-outfit text-gemini-text\">{deleteConfirm.type === 'course' ? t('common.confirmDeleteCourse', { title: deleteConfirm.title || '' }) : t('common.confirmDeleteTitle', { title: deleteConfirm.title || '' })}</h3>"
)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
