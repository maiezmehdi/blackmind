import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

vv_code = """
  useEffect(() => {
    const handleResize = () => {
      if (window.visualViewport && document.activeElement && document.activeElement.tagName === 'DIV' && document.activeElement.hasAttribute('contenteditable')) {
        const viewportHeight = window.visualViewport.height;
        const rect = document.activeElement.getBoundingClientRect();
        
        // If element is below the visible viewport, scroll it up
        if (rect.bottom > viewportHeight) {
          const canvas = canvasRef.current;
          if (canvas) {
            canvas.scrollBy({
              top: rect.bottom - viewportHeight + 20,
              behavior: 'smooth'
            });
          }
        }
      }
    };
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', handleResize);
      return () => window.visualViewport?.removeEventListener('resize', handleResize);
    }
  }, []);
"""

content = content.replace(
    'const handleOpenSelectKey = async () => {',
    vv_code + '\n  const handleOpenSelectKey = async () => {'
)

# And fix the toolbarPosition to be sticky to the rect in the viewport
content = content.replace(
    'setToolbarPos({ x: rect.left + rect.width / 2, y: rect.top - 10 + window.scrollY });',
    'setToolbarPos({ x: rect.left + rect.width / 2, y: rect.top - 10 });' # Since the toolbar is fixed, we shouldn't add scrollY if we don't need to, but actually if the container scrolls, fixed element needs to update. But on selection change it sets it.
)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)

print("patched visual viewport")
