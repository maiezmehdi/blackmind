import re

with open('pages/MarketplacePage.tsx', 'r') as f:
    content = f.read()

def_price = """
  const formatPrice = (priceStr) => {
    if (priceStr === 'Gratuit' || priceStr === 'Free') return t('marketplace.free');
    const num = parseFloat(priceStr);
    if (isNaN(num)) return priceStr;
    return new Intl.NumberFormat(language === 'fr' ? 'fr-FR' : 'en-US', { style: 'currency', currency: 'EUR' }).format(num);
  };
"""

content = content.replace(
    'const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);',
    'const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);\n' + def_price
)

# And replace usage
content = content.replace(
    "{selectedCourse.price === 'Gratuit' ? t('marketplace.free') : selectedCourse.price}",
    "{formatPrice(selectedCourse.price)}"
)
content = content.replace(
    "{featuredCourse.price === 'Gratuit' && (",
    "{featuredCourse.price === 'Gratuit' && ("
) # unchanged, maybe it's fine if the value is 'Gratuit'
content = content.replace(
    "{featuredCourse.price}",
    "{formatPrice(featuredCourse.price)}"
)
content = content.replace(
    "{course.price}",
    "{formatPrice(course.price)}"
)

with open('pages/MarketplacePage.tsx', 'w') as f:
    f.write(content)
