import re

with open('pages/MarketplacePage.tsx', 'r') as f:
    content = f.read()

# Add favorites category
content = content.replace(
    'const categoryKeys = ["all", "ai", "dev", "design", "business", "languages", "science"];',
    'const categoryKeys = ["all", "favorites", "ai", "dev", "design", "business", "languages", "science"];'
)

# Update filter logic
new_filter = """    return marketplaceCourses.filter(c => {
      if (selectedCategoryKey === 'favorites') {
        return favorites.includes(c.id);
      }
      const selectedCategoryLabel = t(`categories.${selectedCategoryKey}`);
      const matchesCategory = selectedCategoryKey === "all" || c.category === selectedCategoryLabel || c.category === selectedCategoryKey || (selectedCategoryKey === 'dev' && c.category === 'Développement') || (selectedCategoryKey === 'dev' && c.category === 'Development');
      
      const matchesSearch = c.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           c.description.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesCategory && matchesSearch;
    });"""

content = re.sub(r'return marketplaceCourses\.filter\(c => \{.*?\n\s+return matchesCategory && matchesSearch;\n\s+\}\);', new_filter, content, flags=re.DOTALL)

# And make sure favorites state is a dependency of filteredCourses
content = content.replace(
    '}, [marketplaceCourses, selectedCategoryKey, searchTerm, t]);',
    '}, [marketplaceCourses, selectedCategoryKey, searchTerm, t, favorites]);'
)

with open('pages/MarketplacePage.tsx', 'w') as f:
    f.write(content)

