import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

pattern = r'<button onClick=\{\(\) => setIsPreviewMode\(!isPreviewMode\)\} className=\{`p-2 rounded-lg transition-colors border \$\{isPreviewMode \? \'bg-gemini-accent text-gemini-bg border-gemini-accent\' : \'text-gemini-dim border-gemini-border hover:bg-gemini-surface\'\}`\} title=\{isPreviewMode \? \'Quitter le mode aperçu\' : \'Mode aperçu\'\}>\{isPreviewMode \? <EyeOff size=\{18\} /> : <Eye size=\{18\} />\}</button>'

content = re.sub(pattern, '', content)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)
