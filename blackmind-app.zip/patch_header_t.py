import re

with open('components/Layout/Header.tsx', 'r') as f:
    content = f.read()

# Make sure we import useLanguage
if 'useLanguage' not in content:
    content = content.replace("import { useCourseContext } from '../../store/useCourseStore';", "import { useCourseContext } from '../../store/useCourseStore';\nimport { useLanguage } from '../../contexts/LanguageContext';")

# Extract t from useLanguage
if 'const { t } = useLanguage();' not in content:
    content = content.replace("const { currentUser } = useCourseContext();", "const { currentUser } = useCourseContext();\n  const { t } = useLanguage();")

# Replace placeholders
content = content.replace('placeholder="Rechercher un cours..."', 'placeholder={t(\'common.searchCourse\')}')
content = content.replace('placeholder="Rechercher..."', 'placeholder={t(\'common.search\')}')

with open('components/Layout/Header.tsx', 'w') as f:
    f.write(content)
