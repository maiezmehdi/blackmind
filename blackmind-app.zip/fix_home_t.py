import re

with open('pages/HomePage.tsx', 'r') as f:
    content = f.read()

content = content.replace("const { courses, deleteCourse, t } = useCourseContext();", "const { courses, deleteCourse } = useCourseContext();")
content = content.replace("const { t } = useLanguage();", "const { language, t } = useLanguage();")

with open('pages/HomePage.tsx', 'w') as f:
    f.write(content)

with open('components/Layout/Sidebar.tsx', 'r') as f:
    content = f.read()
content = content.replace('const { language, t } = useLanguage();', 'const { language, t } = useLanguage();')
# remove extra t from useCourseContext if any
content = content.replace('const { t, currentUser } = useCourseContext();', 'const { currentUser } = useCourseContext();')

with open('components/Layout/Sidebar.tsx', 'w') as f:
    f.write(content)
