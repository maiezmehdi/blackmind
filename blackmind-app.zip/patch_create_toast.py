import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

# Remove the old fixed toast
content = re.sub(
    r'\{showSaveIndicator && lastSaved && \(\s*<div className="fixed top-20 left-1/2 -translate-x-1/2 z-\[150\].*?</div>\s*\)\}',
    '',
    content,
    flags=re.DOTALL
)

# Add it to the header
header_insertion = """
        <div className="flex items-center gap-3 relative" ref={actionMenuRef}>
          {showSaveIndicator && lastSaved && (
             <div className="hidden md:flex items-center gap-1.5 px-3 py-1 bg-gemini-surface/50 border border-gemini-border rounded-full text-[9px] font-bold uppercase tracking-widest text-gemini-dim">
               <History size={10} className="text-gemini-accent" /> {t('common.save', { defaultValue: 'Enregistré' })} · {lastSaved.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
             </div>
          )}
"""

content = content.replace('<div className="flex items-center gap-3 relative" ref={actionMenuRef}>', header_insertion)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)

print("patched save toast")
