import re

with open('index.html', 'r') as f:
    content = f.read()

# Add warning, danger tokens to :root
root_tokens = """
        --gemini-bg: #FFFFFF;
        --gemini-surface: #F8F9FA;
        --gemini-header: rgba(255, 255, 255, 0.8);
        --gemini-sidebar: #FFFFFF;
        --gemini-border: rgba(0, 0, 0, 0.1);
        --gemini-text: #171717;
        --gemini-dim: #525252;
        --gemini-accent: #000000;
        --gemini-warning-bg: #FFFBEB;
        --gemini-warning-border: #FEF3C7;
        --gemini-warning-text: #B45309;
        --gemini-danger-bg: #FEF2F2;
        --gemini-danger-text: #DC2626;
"""

dark_tokens = """
        --gemini-bg: #0A0A0B; 
        --gemini-surface: #121214;
        --gemini-header: rgba(10, 10, 11, 0.8);
        --gemini-sidebar: #0A0A0B;
        --gemini-border: rgba(255, 255, 255, 0.1);
        --gemini-text: #F5F5F5;
        --gemini-dim: #A3A3A3;
        --gemini-accent: #FFFFFF;
        --gemini-warning-bg: rgba(245, 158, 11, 0.1);
        --gemini-warning-border: rgba(245, 158, 11, 0.2);
        --gemini-warning-text: #FBBF24;
        --gemini-danger-bg: rgba(239, 68, 68, 0.1);
        --gemini-danger-text: #F87171;
"""

contrast_tokens = """
        --gemini-bg: #000000 !important;
        --gemini-surface: #000000 !important;
        --gemini-header: #000000 !important;
        --gemini-sidebar: #000000 !important;
        --gemini-border: #FFFFFF !important;
        --gemini-text: #FFFFFF !important;
        --gemini-dim: #FFFF00 !important;
        --gemini-accent: #00FFFF !important;
        --gemini-warning-bg: #000000 !important;
        --gemini-warning-border: #FFFF00 !important;
        --gemini-warning-text: #FFFF00 !important;
        --gemini-danger-bg: #000000 !important;
        --gemini-danger-text: #FF0000 !important;
"""

content = re.sub(r':root\s*\{[^}]*\}', ':root {' + root_tokens + '}', content, count=1)
content = re.sub(r'\.dark\s*\{[^}]*\}', '.dark {' + dark_tokens + '}', content, count=1)
content = re.sub(r'\.mode-contrast\s*\{[^}]*\}', '.mode-contrast {' + contrast_tokens + '}', content, count=1)

# Add to tailwind config
tailwind_colors = """            colors: {
              gemini: {
                bg: 'var(--gemini-bg)',
                surface: 'var(--gemini-surface)',
                header: 'var(--gemini-header)',
                sidebar: 'var(--gemini-sidebar)',
                border: 'var(--gemini-border)',
                text: 'var(--gemini-text)',
                dim: 'var(--gemini-dim)',
                accent: 'var(--gemini-accent)',
                warning: {
                  bg: 'var(--gemini-warning-bg)',
                  border: 'var(--gemini-warning-border)',
                  text: 'var(--gemini-warning-text)',
                },
                danger: {
                  bg: 'var(--gemini-danger-bg)',
                  text: 'var(--gemini-danger-text)',
                }
              }
            },"""
content = re.sub(r'colors:\s*\{[^{]*\{[^}]*\}[^}]*\},', tailwind_colors, content, count=1)

with open('index.html', 'w') as f:
    f.write(content)

print("patched CSS tokens")
