import re

with open('pages/CreatePage.tsx', 'r') as f:
    content = f.read()

old_btn = """                              <button
                                key={sIdx}
                                onClick={() => setView('preview')}
                                className="px-6 py-2.5 bg-gemini-accent text-gemini-bg rounded-full text-[10px] font-bold tracking-wider hover:scale-105 transition-all shadow-lg whitespace-nowrap"
                              >
                                {t('create.viewResult') || 'Voir le résultat ->'}
                              </button>"""

new_btn = """                              <div key={sIdx} className="relative group inline-block">
                                <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-500 via-amber-500 to-pink-500 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-pulse"></div>
                                <button
                                  onClick={() => setView('preview')}
                                  className="relative px-8 py-3 bg-gemini-accent text-gemini-bg rounded-full text-[10px] font-bold tracking-wider hover:scale-105 transition-all shadow-lg whitespace-nowrap flex items-center gap-2"
                                >
                                  {t('create.viewResult') || 'Voir le résultat ->'} <ArrowRight size={14} />
                                </button>
                              </div>"""

content = content.replace(old_btn, new_btn)

with open('pages/CreatePage.tsx', 'w') as f:
    f.write(content)

